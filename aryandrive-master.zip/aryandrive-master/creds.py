class Creds():
    # ENTER Your bot Token Here
    TG_TOKEN = "1180439130:AAGblo616tGQ9Fn9IZuaVz-YU-cKth2a9hg"
    
    
    
    #  Make Sure You Are Providing both value if you need Teamdrive upload
    # Because of pydrive And pydrive v2 Api
    
    #Folder Id Of Teamdrive
    TEAMDRIVE_FOLDER_ID = "1zeRwZiHHaGOGN_3oCqtUR8cBVKOpmmnK"
    
    # Id of Team drive 
    TEAMDRIVE_ID = "0AGkpbJZyyYMZUk9PVA"
    
    
    
    #Example 
    #TG_TOKEN = "dkjfksdkffdkfdkfdj"
    #TEAMDRIVE_FOLDER_ID = "13v4MaZnBz-iEHlZ0gFXk7rh"
    #TEAMDRIVE_ID = "0APh6R4WVvguEUk9PV"
